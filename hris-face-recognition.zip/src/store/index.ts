import { create } from 'zustand'

export interface Employee {
  id: string
  employeeId: string
  name: string
  email: string
  phone: string | null
  position: string
  departmentId: string | null
  department: { id: string; name: string } | null
  faceDescriptor: string | null
  photoUrl: string | null
  isActive: boolean
  createdAt: string
  updatedAt: string
}

export interface Attendance {
  id: string
  employeeId: string
  employee: Employee
  date: string
  clockIn: string | null
  clockOut: string | null
  clockInPhoto: string | null
  clockOutPhoto: string | null
  clockInLocation: string | null
  clockOutLocation: string | null
  status: string
  notes: string | null
  createdAt: string
  updatedAt: string
}

export interface DashboardStats {
  totalEmployees: number
  presentToday: number
  lateToday: number
  absentToday: number
  recentAttendance: Attendance[]
  weeklyData: { date: string; present: number; late: number; absent: number }[]
  departmentBreakdown: { name: string; count: number }[]
}

export interface Settings {
  companyName: string
  workStartTime: string
  workEndTime: string
  lateThreshold: number
}

interface HRISState {
  // Employees
  employees: Employee[]
  setEmployees: (employees: Employee[]) => void
  addEmployee: (employee: Employee) => void
  updateEmployee: (id: string, employee: Partial<Employee>) => void
  removeEmployee: (id: string) => void

  // Attendance
  attendance: Attendance[]
  setAttendance: (attendance: Attendance[]) => void
  todayAttendance: Attendance | null
  setTodayAttendance: (attendance: Attendance | null) => void

  // Dashboard
  dashboardStats: DashboardStats | null
  setDashboardStats: (stats: DashboardStats) => void

  // Settings
  settings: Settings
  setSettings: (settings: Settings) => void

  // UI State
  currentTab: string
  setCurrentTab: (tab: string) => void
  isLoading: boolean
  setIsLoading: (loading: boolean) => void

  // Face Recognition
  faceDetected: boolean
  setFaceDetected: (detected: boolean) => void
  currentFaceDescriptor: number[] | null
  setCurrentFaceDescriptor: (descriptor: number[] | null) => void
  capturedPhoto: string | null
  setCapturedPhoto: (photo: string | null) => void
}

const defaultSettings: Settings = {
  companyName: 'PT. Example Company',
  workStartTime: '09:00',
  workEndTime: '17:00',
  lateThreshold: 15,
}

export const useHRISStore = create<HRISState>((set) => ({
  // Employees
  employees: [],
  setEmployees: (employees) => set({ employees }),
  addEmployee: (employee) => set((state) => ({ employees: [...state.employees, employee] })),
  updateEmployee: (id, employee) =>
    set((state) => ({
      employees: state.employees.map((e) => (e.id === id ? { ...e, ...employee } : e)),
    })),
  removeEmployee: (id) => set((state) => ({ employees: state.employees.filter((e) => e.id !== id) })),

  // Attendance
  attendance: [],
  setAttendance: (attendance) => set({ attendance }),
  todayAttendance: null,
  setTodayAttendance: (attendance) => set({ todayAttendance: attendance }),

  // Dashboard
  dashboardStats: null,
  setDashboardStats: (stats) => set({ dashboardStats: stats }),

  // Settings
  settings: defaultSettings,
  setSettings: (settings) => set({ settings }),

  // UI State
  currentTab: 'clock',
  setCurrentTab: (tab) => set({ currentTab: tab }),
  isLoading: false,
  setIsLoading: (loading) => set({ isLoading: loading }),

  // Face Recognition
  faceDetected: false,
  setFaceDetected: (detected) => set({ faceDetected: detected }),
  currentFaceDescriptor: null,
  setCurrentFaceDescriptor: (descriptor) => set({ currentFaceDescriptor: descriptor }),
  capturedPhoto: null,
  setCapturedPhoto: (photo) => set({ capturedPhoto: photo }),
}))
