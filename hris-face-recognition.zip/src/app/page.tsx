'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { useHRISStore } from '@/store'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog'
import { toast } from 'sonner'
import { 
  Clock, Users, UserCheck, UserX, Building2, Settings, LogOut, 
  Camera, CheckCircle, XCircle, AlertCircle, Search, Plus, 
  Trash2, Edit, Download, Calendar, TrendingUp, BarChart3,
  Fingerprint, Video, VideoOff, RefreshCw
} from 'lucide-react'
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, LineChart, Line } from 'recharts'

// Face API types
declare global {
  interface Window {
    faceapi: typeof import('face-api.js')
  }
}

export default function HRISApp() {
  const [mounted, setMounted] = useState(false)
  const [faceApiLoaded, setFaceApiLoaded] = useState(false)
  const [modelsLoaded, setModelsLoaded] = useState(false)

  const loadModels = useCallback(async () => {
    try {
      const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model'
      await Promise.all([
        window.faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
        window.faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
        window.faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
        window.faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL),
      ])
      setModelsLoaded(true)
      toast.success('Face recognition models loaded')
    } catch (error) {
      console.error('Error loading models:', error)
      toast.error('Failed to load face recognition models')
    }
  }, [])

  const loadFaceAPI = useCallback(async () => {
    try {
      // Load face-api.js from CDN
      const script = document.createElement('script')
      script.src = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api/dist/face-api.min.js'
      script.async = true
      script.onload = async () => {
        setFaceApiLoaded(true)
        await loadModels()
      }
      document.head.appendChild(script)
    } catch (error) {
      console.error('Error loading face-api:', error)
      toast.error('Failed to load face recognition library')
    }
  }, [loadModels])

  // Mount effect - load face API on mount
  useEffect(() => {
    loadFaceAPI()
  }, [loadFaceAPI])

  // Set mounted state after initial render
  useEffect(() => {
    // Use requestAnimationFrame to defer setState outside effect
    const frame = requestAnimationFrame(() => {
      setMounted(true)
    })
    return () => cancelAnimationFrame(frame)
  }, [])

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-white">Loading HRIS System...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
      <Header />
      <main className="container mx-auto px-4 py-6">
        <Tabs defaultValue="clock" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 lg:w-auto lg:inline-grid">
            <TabsTrigger value="clock" className="flex items-center gap-2">
              <Fingerprint className="h-4 w-4" />
              <span className="hidden sm:inline">Clock In/Out</span>
            </TabsTrigger>
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </TabsTrigger>
            <TabsTrigger value="employees" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Employees</span>
            </TabsTrigger>
            <TabsTrigger value="reports" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span className="hidden sm:inline">Reports</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">Settings</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="clock">
            <ClockTab faceApiLoaded={faceApiLoaded && modelsLoaded} />
          </TabsContent>
          <TabsContent value="dashboard">
            <DashboardTab />
          </TabsContent>
          <TabsContent value="employees">
            <EmployeesTab faceApiLoaded={faceApiLoaded && modelsLoaded} />
          </TabsContent>
          <TabsContent value="reports">
            <ReportsTab />
          </TabsContent>
          <TabsContent value="settings">
            <SettingsTab />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

// Header Component
function Header() {
  const { settings } = useHRISStore()
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  return (
    <header className="bg-white dark:bg-slate-800 shadow-sm border-b">
      <div className="container mx-auto px-4 py-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-blue-500 to-purple-600 p-2 rounded-lg">
              <Building2 className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900 dark:text-white">{settings.companyName}</h1>
              <p className="text-sm text-slate-500 dark:text-slate-400">HRIS Face Recognition System</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-mono font-bold text-slate-900 dark:text-white">
              {currentTime.toLocaleTimeString()}
            </div>
            <div className="text-sm text-slate-500 dark:text-slate-400">
              {currentTime.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}

// Clock In/Out Tab
function ClockTab({ faceApiLoaded }: { faceApiLoaded: boolean }) {
  const [isCameraActive, setIsCameraActive] = useState(false)
  const [detectedFace, setDetectedFace] = useState(false)
  const [identifiedEmployee, setIdentifiedEmployee] = useState<{ id: string; name: string; confidence: number } | null>(null)
  const [currentTime, setCurrentTime] = useState(new Date())
  const [isLoading, setIsLoading] = useState(false)
  const [todayStatus, setTodayStatus] = useState<{ clockIn: string | null; clockOut: string | null; status: string } | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const { employees, todayAttendance, settings } = useHRISStore()

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  useEffect(() => {
    fetchTodayStatus()
  }, [])

  const fetchTodayStatus = async () => {
    try {
      const response = await fetch('/api/attendance/today')
      if (response.ok) {
        const data = await response.json()
        useHRISStore.getState().setTodayAttendance(data)
        if (data) {
          setTodayStatus({
            clockIn: data.clockIn,
            clockOut: data.clockOut,
            status: data.status
          })
        }
      }
    } catch (error) {
      console.error('Error fetching today status:', error)
    }
  }

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'user', width: 640, height: 480 } 
      })
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        streamRef.current = stream
        setIsCameraActive(true)
        startFaceDetection()
      }
    } catch (error) {
      console.error('Error accessing camera:', error)
      toast.error('Could not access camera. Please check permissions.')
    }
  }

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop())
      streamRef.current = null
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null
    }
    setIsCameraActive(false)
    setDetectedFace(false)
    setIdentifiedEmployee(null)
  }

  const startFaceDetection = async () => {
    if (!faceApiLoaded || !videoRef.current || !canvasRef.current) return

    const video = videoRef.current
    const canvas = canvasRef.current

    const detectFace = async () => {
      if (!isCameraActive || !video.paused !== false) {
        requestAnimationFrame(detectFace)
        return
      }

      try {
        const detections = await window.faceapi.detectAllFaces(
          video,
          new window.faceapi.TinyFaceDetectorOptions()
        ).withFaceLandmarks().withFaceDescriptors()

        // Clear canvas
        const ctx = canvas.getContext('2d')
        if (ctx) {
          ctx.clearRect(0, 0, canvas.width, canvas.height)
        }

        if (detections.length > 0) {
          setDetectedFace(true)
          
          // Draw detection box
          const detection = detections[0]
          const box = detection.detection.box
          if (ctx) {
            ctx.strokeStyle = '#00ff00'
            ctx.lineWidth = 3
            ctx.strokeRect(box.x, box.y, box.width, box.height)
          }

          // Match face with registered employees
          if (employees.length > 0) {
            let bestMatch: { employeeId: string; name: string; confidence: number } | null = null
            let bestDistance = 0.6 // Threshold

            for (const employee of employees) {
              if (employee.faceDescriptor) {
                try {
                  const storedDescriptor = JSON.parse(employee.faceDescriptor)
                  const distance = window.faceapi.euclideanDistance(
                    detection.descriptor,
                    storedDescriptor
                  )
                  
                  if (distance < bestDistance) {
                    bestDistance = distance
                    bestMatch = {
                      employeeId: employee.id,
                      name: employee.name,
                      confidence: Math.round((1 - distance) * 100)
                    }
                  }
                } catch (e) {
                  console.error('Error parsing face descriptor:', e)
                }
              }
            }

            setIdentifiedEmployee(bestMatch)
          }
        } else {
          setDetectedFace(false)
          setIdentifiedEmployee(null)
        }
      } catch (error) {
        console.error('Face detection error:', error)
      }

      if (isCameraActive) {
        requestAnimationFrame(detectFace)
      }
    }

    video.addEventListener('play', detectFace)
  }

  const handleClockIn = async () => {
    if (!identifiedEmployee) {
      toast.error('No face identified. Please register your face first.')
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch('/api/attendance/clock-in', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          employeeId: identifiedEmployee.employeeId,
          settings: settings
        })
      })

      const data = await response.json()
      if (response.ok) {
        toast.success(`Clock in successful! Welcome, ${identifiedEmployee.name}`)
        setTodayStatus({ clockIn: data.clockIn, clockOut: null, status: data.status })
        fetchTodayStatus()
      } else {
        toast.error(data.error || 'Failed to clock in')
      }
    } catch (error) {
      toast.error('Failed to clock in')
    } finally {
      setIsLoading(false)
    }
  }

  const handleClockOut = async () => {
    if (!identifiedEmployee) {
      toast.error('No face identified')
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch('/api/attendance/clock-out', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          employeeId: identifiedEmployee.employeeId,
          settings: settings
        })
      })

      const data = await response.json()
      if (response.ok) {
        toast.success(`Clock out successful! Goodbye, ${identifiedEmployee.name}`)
        setTodayStatus(prev => prev ? { ...prev, clockOut: data.clockOut, status: data.status } : null)
        fetchTodayStatus()
      } else {
        toast.error(data.error || 'Failed to clock out')
      }
    } catch (error) {
      toast.error('Failed to clock out')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      {/* Camera Section */}
      <Card className="overflow-hidden">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Camera className="h-5 w-5" />
            Face Recognition
          </CardTitle>
          <CardDescription>
            {faceApiLoaded ? 'Face recognition ready' : 'Loading face recognition models...'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative aspect-video bg-slate-900 rounded-lg overflow-hidden">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover transform scale-x-[-1]"
            />
            <canvas
              ref={canvasRef}
              width={640}
              height={480}
              className="absolute top-0 left-0 w-full h-full transform scale-x-[-1]"
            />
            
            {!isCameraActive && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900/90">
                <VideoOff className="h-16 w-16 text-slate-400 mb-4" />
                <p className="text-slate-400 mb-4">Camera is off</p>
                <Button onClick={startCamera} disabled={!faceApiLoaded}>
                  <Video className="h-4 w-4 mr-2" />
                  Start Camera
                </Button>
              </div>
            )}

            {/* Face detection status overlay */}
            {isCameraActive && (
              <div className="absolute top-4 left-4 right-4 flex justify-between items-start">
                <Badge variant={detectedFace ? "default" : "destructive"} className="bg-green-500">
                  {detectedFace ? 'Face Detected' : 'No Face'}
                </Badge>
                <Button size="sm" variant="secondary" onClick={stopCamera}>
                  <VideoOff className="h-4 w-4 mr-2" />
                  Stop
                </Button>
              </div>
            )}

            {/* Identified employee */}
            {identifiedEmployee && (
              <div className="absolute bottom-4 left-4 right-4">
                <Card className="bg-white/95 dark:bg-slate-800/95 backdrop-blur">
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center">
                      <UserCheck className="h-6 w-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-lg">{identifiedEmployee.name}</p>
                      <p className="text-sm text-slate-500">
                        Confidence: {identifiedEmployee.confidence}%
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>

          {/* Clock buttons */}
          {isCameraActive && (
            <div className="flex gap-4 mt-4">
              <Button
                className="flex-1 h-14 text-lg"
                onClick={handleClockIn}
                disabled={!detectedFace || !identifiedEmployee || isLoading || !!todayStatus?.clockIn}
                variant="default"
              >
                <LogOut className="h-5 w-5 mr-2 rotate-180" />
                Clock In
              </Button>
              <Button
                className="flex-1 h-14 text-lg"
                onClick={handleClockOut}
                disabled={!detectedFace || !identifiedEmployee || isLoading || !todayStatus?.clockIn || !!todayStatus?.clockOut}
                variant="secondary"
              >
                <LogOut className="h-5 w-5 mr-2" />
                Clock Out
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Status Section */}
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Today&apos;s Status</CardTitle>
            <CardDescription>
              {currentTime.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800">
                <p className="text-sm text-slate-500">Clock In</p>
                <p className="text-2xl font-bold">{todayStatus?.clockIn || '--:--:--'}</p>
              </div>
              <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800">
                <p className="text-sm text-slate-500">Clock Out</p>
                <p className="text-2xl font-bold">{todayStatus?.clockOut || '--:--:--'}</p>
              </div>
            </div>
            
            {todayStatus && (
              <div className="flex items-center gap-2">
                <Badge variant={todayStatus.status === 'PRESENT' ? 'default' : todayStatus.status === 'LATE' ? 'destructive' : 'secondary'}>
                  {todayStatus.status === 'PRESENT' ? (
                    <><CheckCircle className="h-3 w-3 mr-1" /> On Time</>
                  ) : todayStatus.status === 'LATE' ? (
                    <><AlertCircle className="h-3 w-3 mr-1" /> Late</>
                  ) : (
                    <><Clock className="h-3 w-3 mr-1" /> {todayStatus.status}</>
                  )}
                </Badge>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Work Schedule</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Start Time</span>
                <span className="font-semibold">{settings.workStartTime}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">End Time</span>
                <span className="font-semibold">{settings.workEndTime}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Late Threshold</span>
                <span className="font-semibold">{settings.lateThreshold} minutes</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Stats</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 rounded-lg bg-green-50 dark:bg-green-900/20">
                <p className="text-3xl font-bold text-green-600">{employees.filter(e => e.isActive).length}</p>
                <p className="text-sm text-green-600">Active Employees</p>
              </div>
              <div className="text-center p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                <p className="text-3xl font-bold text-blue-600">{employees.filter(e => e.faceDescriptor).length}</p>
                <p className="text-sm text-blue-600">Face Registered</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Dashboard Tab
function DashboardTab() {
  const { dashboardStats, setDashboardStats, settings } = useHRISStore()
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    fetchDashboardStats()
  }, [])

  const fetchDashboardStats = async () => {
    try {
      const response = await fetch('/api/dashboard')
      if (response.ok) {
        const data = await response.json()
        setDashboardStats(data)
      }
    } catch (error) {
      console.error('Error fetching dashboard:', error)
    } finally {
      setIsLoading(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  const chartConfig = {
    present: { label: "Present", color: "#22c55e" },
    late: { label: "Late", color: "#ef4444" },
    absent: { label: "Absent", color: "#6b7280" },
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100">Total Employees</p>
                <p className="text-3xl font-bold">{dashboardStats?.totalEmployees || 0}</p>
              </div>
              <Users className="h-10 w-10 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100">Present Today</p>
                <p className="text-3xl font-bold">{dashboardStats?.presentToday || 0}</p>
              </div>
              <UserCheck className="h-10 w-10 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-100">Late Today</p>
                <p className="text-3xl font-bold">{dashboardStats?.lateToday || 0}</p>
              </div>
              <AlertCircle className="h-10 w-10 text-orange-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-500 to-red-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-100">Absent Today</p>
                <p className="text-3xl font-bold">{dashboardStats?.absentToday || 0}</p>
              </div>
              <UserX className="h-10 w-10 text-red-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Weekly Attendance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={chartConfig} className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dashboardStats?.weeklyData || []}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="date" 
                    tickFormatter={(value) => new Date(value).toLocaleDateString('id-ID', { weekday: 'short' })}
                  />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="present" fill="#22c55e" name="Present" />
                  <Bar dataKey="late" fill="#ef4444" name="Late" />
                  <Bar dataKey="absent" fill="#6b7280" name="Absent" />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Department Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {dashboardStats?.departmentBreakdown?.map((dept, index) => (
                <div key={dept.name}>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">{dept.name}</span>
                    <span className="text-sm text-slate-500">{dept.count} employees</span>
                  </div>
                  <Progress 
                    value={(dept.count / (dashboardStats?.totalEmployees || 1)) * 100} 
                    className="h-2"
                  />
                </div>
              ))}
              {(!dashboardStats?.departmentBreakdown || dashboardStats.departmentBreakdown.length === 0) && (
                <p className="text-center text-slate-500 py-8">No departments created yet</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Attendance */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Attendance</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employee</TableHead>
                <TableHead>Department</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Clock In</TableHead>
                <TableHead>Clock Out</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {dashboardStats?.recentAttendance?.map((record) => (
                <TableRow key={record.id}>
                  <TableCell className="font-medium">{record.employee?.name}</TableCell>
                  <TableCell>{record.employee?.department?.name || '-'}</TableCell>
                  <TableCell>{new Date(record.date).toLocaleDateString('id-ID')}</TableCell>
                  <TableCell>{record.clockIn || '-'}</TableCell>
                  <TableCell>{record.clockOut || '-'}</TableCell>
                  <TableCell>
                    <Badge variant={record.status === 'PRESENT' ? 'default' : record.status === 'LATE' ? 'destructive' : 'secondary'}>
                      {record.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
              {(!dashboardStats?.recentAttendance || dashboardStats.recentAttendance.length === 0) && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-slate-500 py-8">
                    No recent attendance records
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

// Employees Tab
function EmployeesTab({ faceApiLoaded }: { faceApiLoaded: boolean }) {
  const { employees, setEmployees, removeEmployee } = useHRISStore()
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingEmployee, setEditingEmployee] = useState<{ id: string; name: string; email: string; phone: string; position: string; departmentId: string } | null>(null)
  const [departments, setDepartments] = useState<{ id: string; name: string }[]>([])

  useEffect(() => {
    fetchEmployees()
    fetchDepartments()
  }, [])

  const fetchEmployees = async () => {
    try {
      const response = await fetch('/api/employees')
      if (response.ok) {
        const data = await response.json()
        setEmployees(data)
      }
    } catch (error) {
      console.error('Error fetching employees:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const fetchDepartments = async () => {
    try {
      const response = await fetch('/api/seed')
      if (response.ok) {
        const data = await response.json()
        setDepartments(data)
      }
    } catch (error) {
      console.error('Error fetching departments:', error)
    }
  }

  const handleDelete = async (id: string) => {
    try {
      const response = await fetch(`/api/employees/${id}`, { method: 'DELETE' })
      if (response.ok) {
        removeEmployee(id)
        toast.success('Employee deleted successfully')
      } else {
        toast.error('Failed to delete employee')
      }
    } catch (error) {
      toast.error('Failed to delete employee')
    }
  }

  const filteredEmployees = employees.filter(emp =>
    emp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    emp.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    emp.employeeId.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Search employees..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <EmployeeFormDialog
          isOpen={isDialogOpen}
          onClose={() => { setIsDialogOpen(false); setEditingEmployee(null) }}
          onSuccess={() => { fetchEmployees(); setIsDialogOpen(false); setEditingEmployee(null) }}
          departments={departments}
          faceApiLoaded={faceApiLoaded}
          editingEmployee={editingEmployee}
        />
        <Button onClick={() => setIsDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Employee
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employee ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Position</TableHead>
                <TableHead>Department</TableHead>
                <TableHead>Face Status</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8">
                    Loading...
                  </TableCell>
                </TableRow>
              ) : filteredEmployees.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8 text-slate-500">
                    No employees found
                  </TableCell>
                </TableRow>
              ) : (
                filteredEmployees.map((employee) => (
                  <TableRow key={employee.id}>
                    <TableCell className="font-mono">{employee.employeeId}</TableCell>
                    <TableCell className="font-medium">{employee.name}</TableCell>
                    <TableCell>{employee.email}</TableCell>
                    <TableCell>{employee.position}</TableCell>
                    <TableCell>{employee.department?.name || '-'}</TableCell>
                    <TableCell>
                      <Badge variant={employee.faceDescriptor ? 'default' : 'secondary'}>
                        {employee.faceDescriptor ? 'Registered' : 'Not Registered'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={employee.isActive ? 'default' : 'destructive'}>
                        {employee.isActive ? 'Active' : 'Inactive'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setEditingEmployee({
                              id: employee.id,
                              name: employee.name,
                              email: employee.email,
                              phone: employee.phone || '',
                              position: employee.position,
                              departmentId: employee.departmentId || ''
                            })
                            setIsDialogOpen(true)
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button size="sm" variant="ghost" className="text-red-500">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Employee</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete {employee.name}? This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                className="bg-red-500 hover:bg-red-600"
                                onClick={() => handleDelete(employee.id)}
                              >
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

// Employee Form Dialog
function EmployeeFormDialog({ 
  isOpen, 
  onClose, 
  onSuccess, 
  departments, 
  faceApiLoaded,
  editingEmployee 
}: { 
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
  departments: { id: string; name: string }[]
  faceApiLoaded: boolean
  editingEmployee: { id: string; name: string; email: string; phone: string; position: string; departmentId: string } | null
}) {
  const [formData, setFormData] = useState({
    employeeId: '',
    name: '',
    email: '',
    phone: '',
    position: '',
    departmentId: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showFaceCapture, setShowFaceCapture] = useState(false)
  const [faceDescriptor, setFaceDescriptor] = useState<number[] | null>(null)
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const streamRef = useRef<MediaStream | null>(null)

  useEffect(() => {
    if (editingEmployee) {
      setFormData({
        employeeId: editingEmployee.employeeId || '',
        name: editingEmployee.name || '',
        email: editingEmployee.email || '',
        phone: editingEmployee.phone || '',
        position: editingEmployee.position || '',
        departmentId: editingEmployee.departmentId || ''
      })
    } else {
      setFormData({
        employeeId: '',
        name: '',
        email: '',
        phone: '',
        position: '',
        departmentId: ''
      })
    }
  }, [editingEmployee, isOpen])

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'user', width: 640, height: 480 } 
      })
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        streamRef.current = stream
        setShowFaceCapture(true)
      }
    } catch (error) {
      toast.error('Could not access camera')
    }
  }

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop())
      streamRef.current = null
    }
    setShowFaceCapture(false)
  }

  const captureFace = async () => {
    if (!faceApiLoaded || !videoRef.current || !canvasRef.current) return

    try {
      const video = videoRef.current
      const canvas = canvasRef.current
      canvas.width = video.videoWidth
      canvas.height = video.videoHeight

      const ctx = canvas.getContext('2d')
      if (ctx) {
        ctx.drawImage(video, 0, 0)
        const photoData = canvas.toDataURL('image/jpeg')
        setCapturedPhoto(photoData)
      }

      const detection = await window.faceapi
        .detectSingleFace(video, new window.faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks()
        .withFaceDescriptor()

      if (detection) {
        setFaceDescriptor(Array.from(detection.descriptor))
        toast.success('Face captured successfully!')
        stopCamera()
      } else {
        toast.error('No face detected. Please try again.')
      }
    } catch (error) {
      console.error('Error capturing face:', error)
      toast.error('Failed to capture face')
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      if (editingEmployee) {
        // Update existing employee
        const response = await fetch(`/api/employees/${editingEmployee.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData)
        })
        if (response.ok) {
          toast.success('Employee updated successfully')
          onSuccess()
        } else {
          const error = await response.json()
          toast.error(error.error || 'Failed to update employee')
        }
      } else {
        // Create new employee
        const response = await fetch('/api/employees', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...formData,
            faceDescriptor,
            photoUrl: capturedPhoto
          })
        })
        if (response.ok) {
          toast.success('Employee created successfully')
          onSuccess()
        } else {
          const error = await response.json()
          toast.error(error.error || 'Failed to create employee')
        }
      }
    } catch (error) {
      toast.error('An error occurred')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{editingEmployee ? 'Edit Employee' : 'Add New Employee'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="employeeId">Employee ID</Label>
              <Input
                id="employeeId"
                value={formData.employeeId}
                onChange={(e) => setFormData({ ...formData, employeeId: e.target.value })}
                placeholder="EMP001"
                required
                disabled={!!editingEmployee}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="John Doe"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="john@example.com"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="+62 812-xxxx-xxxx"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="position">Position</Label>
              <Input
                id="position"
                value={formData.position}
                onChange={(e) => setFormData({ ...formData, position: e.target.value })}
                placeholder="Software Engineer"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="department">Department</Label>
              <Select
                value={formData.departmentId}
                onValueChange={(value) => setFormData({ ...formData, departmentId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept.id} value={dept.id}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Face Registration Section */}
          {!editingEmployee && (
            <div className="space-y-4">
              <Label>Face Registration</Label>
              <div className="relative aspect-video bg-slate-100 dark:bg-slate-800 rounded-lg overflow-hidden">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className={cn("w-full h-full object-cover transform scale-x-[-1]", !showFaceCapture && "hidden")}
                />
                <canvas ref={canvasRef} className="hidden" />
                
                {!showFaceCapture && !faceDescriptor && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    {capturedPhoto ? (
                      <img src={capturedPhoto} alt="Captured" className="w-full h-full object-cover" />
                    ) : (
                      <>
                        <Camera className="h-12 w-12 text-slate-400 mb-2" />
                        <p className="text-slate-500 text-sm">Click below to capture face</p>
                      </>
                    )}
                  </div>
                )}

                {showFaceCapture && (
                  <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
                    <Button type="button" onClick={captureFace}>
                      <Camera className="h-4 w-4 mr-2" />
                      Capture Face
                    </Button>
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                {!showFaceCapture && !faceDescriptor && (
                  <Button type="button" variant="outline" onClick={startCamera} disabled={!faceApiLoaded}>
                    <Camera className="h-4 w-4 mr-2" />
                    Start Camera
                  </Button>
                )}
                {showFaceCapture && (
                  <Button type="button" variant="outline" onClick={stopCamera}>
                    Cancel
                  </Button>
                )}
                {faceDescriptor && (
                  <div className="flex items-center gap-2 text-green-600">
                    <CheckCircle className="h-4 w-4" />
                    <span className="text-sm">Face registered</span>
                  </div>
                )}
              </div>
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Saving...' : editingEmployee ? 'Update' : 'Create Employee'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

// Utility function for className
function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ')
}

// Reports Tab
function ReportsTab() {
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [reportData, setReportData] = useState<unknown[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const generateReport = async () => {
    if (!startDate || !endDate) {
      toast.error('Please select date range')
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch(`/api/attendance/report?startDate=${startDate}&endDate=${endDate}`)
      if (response.ok) {
        const data = await response.json()
        setReportData(data)
      }
    } catch (error) {
      toast.error('Failed to generate report')
    } finally {
      setIsLoading(false)
    }
  }

  const exportToCSV = () => {
    if (reportData.length === 0) return

    const headers = ['Date', 'Employee ID', 'Name', 'Department', 'Clock In', 'Clock Out', 'Status']
    const rows = reportData.map((record: Record<string, unknown>) => [
      record.date,
      (record.employee as Record<string, unknown>)?.employeeId,
      (record.employee as Record<string, unknown>)?.name,
      (record.employee as Record<string, unknown>)?.department?.name || '-',
      record.clockIn || '-',
      record.clockOut || '-',
      record.status
    ])

    const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n')
    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `attendance-report-${startDate}-to-${endDate}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Generate Report</CardTitle>
          <CardDescription>Select date range to generate attendance report</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="space-y-2 flex-1">
              <Label>Start Date</Label>
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <div className="space-y-2 flex-1">
              <Label>End Date</Label>
              <Input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
            <div className="flex items-end gap-2">
              <Button onClick={generateReport} disabled={isLoading}>
                <RefreshCw className={cn("h-4 w-4 mr-2", isLoading && "animate-spin")} />
                Generate
              </Button>
              <Button variant="outline" onClick={exportToCSV} disabled={reportData.length === 0}>
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Attendance Report</CardTitle>
          <CardDescription>
            {reportData.length > 0 ? `${reportData.length} records found` : 'No data to display'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Employee</TableHead>
                <TableHead>Department</TableHead>
                <TableHead>Clock In</TableHead>
                <TableHead>Clock Out</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reportData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-slate-500">
                    Select date range and click Generate to view report
                  </TableCell>
                </TableRow>
              ) : (
                reportData.map((record: Record<string, unknown>) => {
                  const employee = record.employee as Record<string, unknown>
                  return (
                    <TableRow key={record.id as string}>
                      <TableCell>{record.date as string}</TableCell>
                      <TableCell className="font-medium">{employee?.name as string}</TableCell>
                      <TableCell>{(employee?.department as Record<string, unknown>)?.name as string || '-'}</TableCell>
                      <TableCell>{(record.clockIn as string) || '-'}</TableCell>
                      <TableCell>{(record.clockOut as string) || '-'}</TableCell>
                      <TableCell>
                        {record.clockIn && record.clockOut
                          ? calculateDuration(record.clockIn as string, record.clockOut as string)
                          : '-'}
                      </TableCell>
                      <TableCell>
                        <Badge variant={record.status === 'PRESENT' ? 'default' : record.status === 'LATE' ? 'destructive' : 'secondary'}>
                          {record.status as string}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  )
                })
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

// Calculate duration between two times
function calculateDuration(clockIn: string, clockOut: string): string {
  const [inH, inM, inS] = clockIn.split(':').map(Number)
  const [outH, outM, outS] = clockOut.split(':').map(Number)
  
  const inSeconds = inH * 3600 + inM * 60 + inS
  const outSeconds = outH * 3600 + outM * 60 + outS
  
  const diff = outSeconds - inSeconds
  const hours = Math.floor(diff / 3600)
  const minutes = Math.floor((diff % 3600) / 60)
  
  return `${hours}h ${minutes}m`
}

// Settings Tab
function SettingsTab() {
  const { settings, setSettings } = useHRISStore()
  const [formData, setFormData] = useState(settings)
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    fetchSettings()
  }, [])

  const fetchSettings = async () => {
    try {
      const response = await fetch('/api/settings')
      if (response.ok) {
        const data = await response.json()
        setSettings(data)
        setFormData(data)
      }
    } catch (error) {
      console.error('Error fetching settings:', error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const response = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      })
      if (response.ok) {
        const data = await response.json()
        setSettings(data)
        toast.success('Settings saved successfully')
      }
    } catch (error) {
      toast.error('Failed to save settings')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Company Settings
          </CardTitle>
          <CardDescription>Configure your company work hours and attendance rules</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="companyName">Company Name</Label>
              <Input
                id="companyName"
                value={formData.companyName}
                onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                placeholder="PT. Example Company"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="workStartTime">Work Start Time</Label>
                <Input
                  id="workStartTime"
                  type="time"
                  value={formData.workStartTime}
                  onChange={(e) => setFormData({ ...formData, workStartTime: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="workEndTime">Work End Time</Label>
                <Input
                  id="workEndTime"
                  type="time"
                  value={formData.workEndTime}
                  onChange={(e) => setFormData({ ...formData, workEndTime: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="lateThreshold">Late Threshold (minutes)</Label>
              <Input
                id="lateThreshold"
                type="number"
                value={formData.lateThreshold}
                onChange={(e) => setFormData({ ...formData, lateThreshold: parseInt(e.target.value) })}
                min={0}
                max={60}
              />
              <p className="text-sm text-slate-500">
                Employees arriving after this many minutes past start time will be marked as late
              </p>
            </div>

            <Button type="submit" disabled={isSubmitting} className="w-full">
              {isSubmitting ? 'Saving...' : 'Save Settings'}
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>About System</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-between">
            <span className="text-slate-500">Version</span>
            <span className="font-medium">1.0.0</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Face Recognition</span>
            <span className="font-medium">face-api.js</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Framework</span>
            <span className="font-medium">Next.js 15</span>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
