import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - List all employees
export async function GET() {
  try {
    const employees = await db.employee.findMany({
      include: {
        department: true,
      },
      orderBy: {
        createdAt: 'desc',
      },
    })
    return NextResponse.json(employees)
  } catch (error) {
    console.error('Error fetching employees:', error)
    return NextResponse.json({ error: 'Failed to fetch employees' }, { status: 500 })
  }
}

// POST - Create new employee
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { employeeId, name, email, phone, position, departmentId, faceDescriptor, photoUrl } = body

    // Validate required fields
    if (!employeeId || !name || !email || !position) {
      return NextResponse.json(
        { error: 'Missing required fields: employeeId, name, email, position' },
        { status: 400 }
      )
    }

    // Check if employeeId or email already exists
    const existing = await db.employee.findFirst({
      where: {
        OR: [{ employeeId }, { email }],
      },
    })

    if (existing) {
      return NextResponse.json(
        { error: existing.employeeId === employeeId ? 'Employee ID already exists' : 'Email already exists' },
        { status: 400 }
      )
    }

    // Validate departmentId if provided
    let validDepartmentId: string | null = null
    if (departmentId && departmentId.trim() !== '') {
      const department = await db.department.findUnique({
        where: { id: departmentId },
      })
      if (department) {
        validDepartmentId = departmentId
      }
    }

    const employee = await db.employee.create({
      data: {
        employeeId,
        name,
        email,
        phone: phone || null,
        position,
        departmentId: validDepartmentId,
        faceDescriptor: faceDescriptor ? JSON.stringify(faceDescriptor) : null,
        photoUrl: photoUrl || null,
      },
      include: {
        department: true,
      },
    })

    return NextResponse.json(employee, { status: 201 })
  } catch (error) {
    console.error('Error creating employee:', error)
    return NextResponse.json({ error: 'Failed to create employee', details: String(error) }, { status: 500 })
  }
}
