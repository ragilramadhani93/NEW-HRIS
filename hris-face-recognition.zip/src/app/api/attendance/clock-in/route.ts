import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

function getTodayDate(): string {
  return new Date().toISOString().split('T')[0]
}

function getCurrentTime(): string {
  return new Date().toTimeString().split(' ')[0]
}

// POST - Clock in with face recognition
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { employeeId, faceDescriptor, photo, location, settings } = body

    const today = getTodayDate()
    const currentTime = getCurrentTime()

    // Check if employee exists
    const employee = await db.employee.findUnique({
      where: { id: employeeId },
    })

    if (!employee) {
      return NextResponse.json({ error: 'Employee not found' }, { status: 404 })
    }

    // Check if already clocked in today
    const existingAttendance = await db.attendance.findUnique({
      where: {
        employeeId_date: {
          employeeId,
          date: today,
        },
      },
    })

    if (existingAttendance && existingAttendance.clockIn) {
      return NextResponse.json({ error: 'Already clocked in today' }, { status: 400 })
    }

    // Determine status based on work start time
    const workStartTime = settings?.workStartTime || '09:00'
    const lateThreshold = settings?.lateThreshold || 15
    const [workHour, workMinute] = workStartTime.split(':').map(Number)
    const [currentHour, currentMinute] = currentTime.split(':').map(Number).slice(0, 2)
    
    const workMinutes = workHour * 60 + workMinute
    const currentMinutes = currentHour * 60 + currentMinute
    
    const status = currentMinutes > workMinutes + lateThreshold ? 'LATE' : 'PRESENT'

    const attendance = await db.attendance.create({
      data: {
        employeeId,
        date: today,
        clockIn: currentTime,
        clockInPhoto: photo || null,
        clockInLocation: location || null,
        status,
        notes: null,
      },
      include: {
        employee: {
          include: { department: true },
        },
      },
    })

    return NextResponse.json(attendance, { status: 201 })
  } catch (error) {
    console.error('Error clocking in:', error)
    return NextResponse.json({ error: 'Failed to clock in' }, { status: 500 })
  }
}
