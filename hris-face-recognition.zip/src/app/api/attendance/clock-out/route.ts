import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

function getTodayDate(): string {
  return new Date().toISOString().split('T')[0]
}

function getCurrentTime(): string {
  return new Date().toTimeString().split(' ')[0]
}

// POST - Clock out
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { employeeId, photo, location, settings } = body

    const today = getTodayDate()
    const currentTime = getCurrentTime()

    // Check if attendance record exists for today
    const attendance = await db.attendance.findUnique({
      where: {
        employeeId_date: {
          employeeId,
          date: today,
        },
      },
    })

    if (!attendance) {
      return NextResponse.json({ error: 'No clock in record found for today' }, { status: 404 })
    }

    if (attendance.clockOut) {
      return NextResponse.json({ error: 'Already clocked out today' }, { status: 400 })
    }

    // Determine if early leave
    const workEndTime = settings?.workEndTime || '17:00'
    const [workHour, workMinute] = workEndTime.split(':').map(Number)
    const [currentHour, currentMinute] = currentTime.split(':').map(Number).slice(0, 2)
    
    const workMinutes = workHour * 60 + workMinute
    const currentMinutes = currentHour * 60 + currentMinute
    
    const status = currentMinutes < workMinutes - 15 ? 'EARLY_LEAVE' : attendance.status

    const updatedAttendance = await db.attendance.update({
      where: { id: attendance.id },
      data: {
        clockOut: currentTime,
        clockOutPhoto: photo || null,
        clockOutLocation: location || null,
        status,
      },
      include: {
        employee: {
          include: { department: true },
        },
      },
    })

    return NextResponse.json(updatedAttendance)
  } catch (error) {
    console.error('Error clocking out:', error)
    return NextResponse.json({ error: 'Failed to clock out' }, { status: 500 })
  }
}
